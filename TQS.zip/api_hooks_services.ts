/**
 * Mobile Trading App - API Hooks & Services
 * File: src/lib/api.ts
 * Reusable React Query hooks for all API calls
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const API_BASE = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

// ============================================================================
// TYPES
// ============================================================================

export interface ScanResult {
  symbol: string;
  price: number;
  pctChange5m: number;
  relVol5m: number;
  vwapDist: number;
  tags: string[];
  score: number;
  explanations: string[];
}

export interface WatchlistItem {
  id: string;
  symbol: string;
  addedAt: string;
  alerts: any[];
}

export interface Position {
  symbol: string;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPct: number;
  allocation: number;
}

export interface Portfolio {
  timestamp: string;
  totalEquity: number;
  totalPnl: number;
  pnlPct: number;
  positions: Position[];
  leverage: number;
  maxLeverage: number;
}

export interface Run {
  id: string;
  name: string;
  type: "backtest" | "paper";
  status: "running" | "completed" | "failed";
  createdAt: string;
  completedAt?: string;
  metrics?: any;
}

export interface Trade {
  timestamp: string;
  symbol: string;
  quantity: number;
  price: number;
  side: "BUY" | "SELL";
  pnl?: number;
}

export interface Signal {
  symbol: string;
  priority_score: number;
  status: "FILLED" | "BLOCKED" | "SKIPPED";
  reason?: string;
  ml_confidence?: number;
  target_pct: number;
  execution_order: number;
}

export interface Alert {
  id: string;
  symbol: string;
  type: "above" | "below";
  price: number;
  createdAt: string;
  triggered: boolean;
}

// ============================================================================
// SCANNER HOOKS
// ============================================================================

export function useScannerResults(limit: number = 20) {
  return useQuery({
    queryKey: ["scanner", limit],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/scanner?limit=${limit}`);
      if (!res.ok) throw new Error("Failed to fetch scanner results");
      return res.json();
    },
    refetchInterval: 10000, // Refresh every 10s
  });
}

export function useScannerSymbol(symbol: string) {
  return useQuery({
    queryKey: ["scanner", symbol],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/scanner/symbol/${symbol}`);
      if (!res.ok) throw new Error("Symbol not found");
      return res.json();
    },
    enabled: !!symbol,
  });
}

// ============================================================================
// WATCHLIST HOOKS
// ============================================================================

export function useWatchlist() {
  return useQuery({
    queryKey: ["watchlist"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/watchlist`);
      if (!res.ok) throw new Error("Failed to fetch watchlist");
      return res.json();
    },
  });
}

export function useAddToWatchlist() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (symbol: string) => {
      const res = await fetch(`${API_BASE}/mobile/watchlist`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol }),
      });
      if (!res.ok) throw new Error("Failed to add to watchlist");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["watchlist"] });
    },
  });
}

export function useRemoveFromWatchlist() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (symbol: string) => {
      const res = await fetch(`${API_BASE}/mobile/watchlist/${symbol}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Failed to remove from watchlist");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["watchlist"] });
    },
  });
}

// ============================================================================
// PORTFOLIO HOOKS
// ============================================================================

export function usePortfolio() {
  return useQuery({
    queryKey: ["portfolio"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/portfolio`);
      if (!res.ok) throw new Error("Failed to fetch portfolio");
      return res.json() as Promise<Portfolio>;
    },
    refetchInterval: 5000, // Refresh every 5s
  });
}

export function useEquityCurve(days: number = 30) {
  return useQuery({
    queryKey: ["equity-curve", days],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/portfolio/equity-curve?days=${days}`);
      if (!res.ok) throw new Error("Failed to fetch equity curve");
      return res.json();
    },
    refetchInterval: 60000, // Refresh every 60s
  });
}

// ============================================================================
// RUNS HOOKS
// ============================================================================

export function useRuns(limit: number = 10, offset: number = 0) {
  return useQuery({
    queryKey: ["runs", limit, offset],
    queryFn: async () => {
      const res = await fetch(
        `${API_BASE}/mobile/runs?limit=${limit}&offset=${offset}`
      );
      if (!res.ok) throw new Error("Failed to fetch runs");
      return res.json();
    },
  });
}

export function useRun(id: string) {
  return useQuery({
    queryKey: ["runs", id],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/runs/${id}`);
      if (!res.ok) throw new Error("Run not found");
      return res.json() as Promise<Run>;
    },
    enabled: !!id,
  });
}

export function useCreateRun() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: { name: string; configName: string; type?: string }) => {
      const res = await fetch(`${API_BASE}/mobile/runs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create run");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["runs"] });
    },
  });
}

// ============================================================================
// SIGNALS HOOKS (Priority Execution)
// ============================================================================

export function useSignals(runId: string) {
  return useQuery({
    queryKey: ["signals", runId],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/runs/${runId}/signals`);
      if (!res.ok) throw new Error("Failed to fetch signals");
      return res.json();
    },
    enabled: !!runId,
    refetchInterval: 5000, // Refresh every 5s during run
  });
}

export function useRunTrades(runId: string, limit: number = 50, offset: number = 0) {
  return useQuery({
    queryKey: ["trades", runId, limit, offset],
    queryFn: async () => {
      const res = await fetch(
        `${API_BASE}/mobile/runs/${runId}/trades?limit=${limit}&offset=${offset}`
      );
      if (!res.ok) throw new Error("Failed to fetch trades");
      return res.json();
    },
    enabled: !!runId,
  });
}

// ============================================================================
// ALERTS HOOKS
// ============================================================================

export function useAlerts() {
  return useQuery({
    queryKey: ["alerts"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/alerts`);
      if (!res.ok) throw new Error("Failed to fetch alerts");
      return res.json();
    },
    refetchInterval: 30000, // Refresh every 30s
  });
}

export function useCreateAlert() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: { symbol: string; type: "above" | "below"; price: number }) => {
      const res = await fetch(`${API_BASE}/mobile/alerts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create alert");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alerts"] });
    },
  });
}

// ============================================================================
// DASHBOARD HOOKS
// ============================================================================

export function useDashboard() {
  return useQuery({
    queryKey: ["dashboard"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/dashboard`);
      if (!res.ok) throw new Error("Failed to fetch dashboard");
      return res.json();
    },
    refetchInterval: 10000, // Refresh every 10s
  });
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(value);
}

export function formatPercent(value: number): string {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

export function formatNumber(value: number, decimals: number = 2): string {
  return value.toFixed(decimals);
}

export function getPnLColor(value: number): string {
  return value >= 0 ? "text-green-400" : "text-red-400";
}

export function getPnLBgColor(value: number): string {
  return value >= 0 ? "bg-green-900" : "bg-red-900";
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "completed":
      return "bg-green-600";
    case "running":
      return "bg-blue-600";
    case "failed":
      return "bg-red-600";
    default:
      return "bg-gray-600";
  }
}

export function getSignalStatusColor(status: string): string {
  switch (status) {
    case "FILLED":
      return "text-green-400";
    case "BLOCKED":
      return "text-red-400";
    case "SKIPPED":
      return "text-yellow-400";
    default:
      return "text-gray-400";
  }
}
