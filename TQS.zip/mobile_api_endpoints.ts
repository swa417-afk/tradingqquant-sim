/**
 * Mobile Trading App - Complete API Endpoints
 * Build with: Express + WebSocket for real-time updates
 * Usage: Add these routes to your server/routes.ts
 */

import { Router, Request, Response } from "express";
import { db } from "./db";
import { runs, datasets, users } from "@shared/schema";
import { eq } from "drizzle-orm";
import fs from "fs";
import path from "path";

const router = Router();

// ============================================================================
// 1. SCANNER ENDPOINTS - Real-time momentum scanning
// ============================================================================

/**
 * GET /api/mobile/scanner
 * Returns latest scanner results (top 20 momentum stocks)
 */
router.get("/mobile/scanner", async (req: Request, res: Response) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 50);

    // Example: Load from cached scanner results
    // In production, cache these from your Python scanner
    const scannerResultsPath = path.join(
      process.cwd(),
      "quant-sim/runs/latest_scan.json"
    );

    let results = [];
    if (fs.existsSync(scannerResultsPath)) {
      const data = fs.readFileSync(scannerResultsPath, "utf-8");
      results = JSON.parse(data).slice(0, limit);
    }

    res.json({
      timestamp: new Date().toISOString(),
      count: results.length,
      results: results.map((r: any) => ({
        symbol: r.symbol,
        price: r.price,
        pctChange5m: r.pctChange5m,
        relVol5m: r.relVol5m,
        vwapDist: r.vwapDist,
        tags: r.tags,
        score: r.score,
        explanations: r.explanations,
      })),
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * GET /api/mobile/scanner/symbol/:symbol
 * Get detailed scanner info for a single symbol
 */
router.get("/mobile/scanner/symbol/:symbol", async (req: Request, res: Response) => {
  try {
    const { symbol } = req.params;

    // Load from scanner results
    const scannerResultsPath = path.join(
      process.cwd(),
      "quant-sim/runs/latest_scan.json"
    );

    if (!fs.existsSync(scannerResultsPath)) {
      return res.status(404).json({ error: "No scanner results available" });
    }

    const data = JSON.parse(fs.readFileSync(scannerResultsPath, "utf-8"));
    const result = data.find((r: any) => r.symbol === symbol);

    if (!result) {
      return res.status(404).json({ error: `Symbol ${symbol} not found` });
    }

    res.json({
      symbol: result.symbol,
      price: result.price,
      pctChange5m: result.pctChange5m,
      relVol5m: result.relVol5m,
      vwapDist: result.vwapDist,
      tags: result.tags,
      score: result.score,
      explanations: result.explanations,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ============================================================================
// 2. WATCHLIST ENDPOINTS - User's personal watchlist
// ============================================================================

/**
 * GET /api/mobile/watchlist
 * Get user's watchlist with live prices
 */
router.get("/mobile/watchlist", async (req: Request, res: Response) => {
  try {
    // In production: fetch user's watchlist from DB
    // For now, return example structure
    const watchlist = [
      {
        id: "1",
        symbol: "BTC-USD",
        addedAt: new Date().toISOString(),
        alerts: [],
      },
      {
        id: "2",
        symbol: "ETH-USD",
        addedAt: new Date().toISOString(),
        alerts: [],
      },
    ];

    res.json({
      count: watchlist.length,
      items: watchlist,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * POST /api/mobile/watchlist
 * Add symbol to watchlist
 */
router.post("/mobile/watchlist", async (req: Request, res: Response) => {
  try {
    const { symbol } = req.body;

    if (!symbol) {
      return res.status(400).json({ error: "Symbol required" });
    }

    // In production: save to DB
    const item = {
      id: Math.random().toString(36),
      symbol,
      addedAt: new Date().toISOString(),
      alerts: [],
    };

    res.json({
      success: true,
      item,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * DELETE /api/mobile/watchlist/:symbol
 * Remove symbol from watchlist
 */
router.delete("/mobile/watchlist/:symbol", async (req: Request, res: Response) => {
  try {
    const { symbol } = req.params;

    // In production: delete from DB
    res.json({
      success: true,
      removed: symbol,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ============================================================================
// 3. RUNS ENDPOINTS - Backtest & Paper Trading Results
// ============================================================================

/**
 * GET /api/mobile/runs
 * List all backtest/paper trading runs
 */
router.get("/mobile/runs", async (req: Request, res: Response) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 10, 50);
    const offset = Math.min(parseInt(req.query.offset as string) || 0, 1000);

    // In production: query DB
    const allRuns = await db.query.runs.findMany({
      limit,
      offset,
      orderBy: (runs: any) => [runs.createdAt],
    });

    const formatted = allRuns.map((run: any) => ({
      id: run.id,
      name: run.name,
      type: run.type, // 'backtest' or 'paper'
      status: run.status, // 'running', 'completed', 'failed'
      createdAt: run.createdAt,
      completedAt: run.completedAt,
      metrics: run.metrics ? JSON.parse(run.metrics as string) : null,
    }));

    res.json({
      count: formatted.length,
      offset,
      limit,
      runs: formatted,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * GET /api/mobile/runs/:id
 * Get detailed run information
 */
router.get("/mobile/runs/:id", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const run = await db.query.runs.findFirst({
      where: eq(runs.id, id),
    });

    if (!run) {
      return res.status(404).json({ error: "Run not found" });
    }

    // Load metrics and trades
    const metricsPath = path.join(run.artifactsDir, "metrics.json");
    const tradesPath = path.join(run.artifactsDir, "trades.csv");
    const equityCurvePath = path.join(run.artifactsDir, "equity_curve.csv");

    let metrics = null;
    let trades = [];
    let equityCurve = [];

    if (fs.existsSync(metricsPath)) {
      metrics = JSON.parse(fs.readFileSync(metricsPath, "utf-8"));
    }

    if (fs.existsSync(tradesPath)) {
      const csv = fs.readFileSync(tradesPath, "utf-8");
      trades = csv.split("\n").slice(1, 21).map((line: string) => {
        const [ts, symbol, qty, price, side] = line.split(",");
        return { ts, symbol, qty: parseFloat(qty), price: parseFloat(price), side };
      });
    }

    if (fs.existsSync(equityCurvePath)) {
      const csv = fs.readFileSync(equityCurvePath, "utf-8");
      equityCurve = csv
        .split("\n")
        .slice(1)
        .map((line: string) => {
          const [ts, equity] = line.split(",");
          return { ts, equity: parseFloat(equity) };
        });
    }

    res.json({
      id: run.id,
      name: run.name,
      type: run.type,
      status: run.status,
      createdAt: run.createdAt,
      completedAt: run.completedAt,
      metrics,
      recentTrades: trades,
      equityCurveLength: equityCurve.length,
      equityCurveLatest: equityCurve.slice(-10),
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * POST /api/mobile/runs
 * Create new backtest run
 */
router.post("/mobile/runs", async (req: Request, res: Response) => {
  try {
    const { name, configName, type } = req.body;

    if (!name || !configName) {
      return res.status(400).json({ error: "name and configName required" });
    }

    // In production: spawn Python backtest process
    const newRun = {
      id: Math.random().toString(36).substring(7),
      name,
      type: type || "backtest",
      status: "running",
      createdAt: new Date(),
      artifactsDir: `/tmp/quant-sim/runs/${Date.now()}`,
      configSnapshot: configName,
      metrics: null,
      completedAt: null,
    };

    // TODO: Insert into DB
    // await db.insert(runs).values(newRun);

    res.json({
      success: true,
      run: newRun,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ============================================================================
// 4. SIGNAL EXECUTION ENDPOINTS - Priority-based execution tracking
// ============================================================================

/**
 * GET /api/mobile/runs/:id/signals
 * Get signal execution history for a run
 */
router.get("/mobile/runs/:id/signals", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const run = await db.query.runs.findFirst({
      where: eq(runs.id, id),
    });

    if (!run) {
      return res.status(404).json({ error: "Run not found" });
    }

    // Load signal history
    const signalPath = path.join(run.artifactsDir, "signal_history.json");

    let signals = [];
    if (fs.existsSync(signalPath)) {
      const data = JSON.parse(fs.readFileSync(signalPath, "utf-8"));
      signals = data;
    }

    // Compute stats
    const allSignals = signals.flatMap((s: any) => s.signals || []);
    const filled = allSignals.filter((s: any) => s.status === "FILLED");
    const blocked = allSignals.filter((s: any) => s.status === "BLOCKED");

    res.json({
      runId: id,
      totalSignals: allSignals.length,
      summary: {
        filled: filled.length,
        blocked: blocked.length,
        avgPriorityFilled:
          filled.length > 0
            ? filled.reduce((sum: number, s: any) => sum + s.priority_score, 0) /
              filled.length
            : 0,
        avgPriorityBlocked:
          blocked.length > 0
            ? blocked.reduce((sum: number, s: any) => sum + s.priority_score, 0) /
              blocked.length
            : 0,
      },
      latest: signals.length > 0 ? signals[signals.length - 1] : null,
      history: signals.slice(-20), // Last 20 decision ticks
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * GET /api/mobile/runs/:id/trades
 * Get trades for a run (paginated)
 */
router.get("/mobile/runs/:id/trades", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 500);
    const offset = Math.min(parseInt(req.query.offset as string) || 0, 10000);

    const run = await db.query.runs.findFirst({
      where: eq(runs.id, id),
    });

    if (!run) {
      return res.status(404).json({ error: "Run not found" });
    }

    const tradesPath = path.join(run.artifactsDir, "trades.csv");

    let trades = [];
    if (fs.existsSync(tradesPath)) {
      const csv = fs.readFileSync(tradesPath, "utf-8");
      const lines = csv.split("\n").slice(1);

      trades = lines
        .slice(offset, offset + limit)
        .map((line: string) => {
          const [ts, symbol, qty, price, side, pnl] = line.split(",");
          return {
            timestamp: ts,
            symbol,
            quantity: parseFloat(qty),
            price: parseFloat(price),
            side,
            pnl: pnl ? parseFloat(pnl) : 0,
          };
        })
        .filter((t: any) => t.symbol); // Filter empty rows
    }

    res.json({
      runId: id,
      totalCount: trades.length,
      offset,
      limit,
      trades,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ============================================================================
// 5. PORTFOLIO ENDPOINTS - Live P&L tracking
// ============================================================================

/**
 * GET /api/mobile/portfolio
 * Get current portfolio P&L and positions
 */
router.get("/mobile/portfolio", async (req: Request, res: Response) => {
  try {
    // In production: fetch from live trading session or DB
    const portfolio = {
      timestamp: new Date().toISOString(),
      totalEquity: 100000,
      totalPnl: 2500,
      pnlPct: 2.5,
      positions: [
        {
          symbol: "BTC-USD",
          quantity: 0.5,
          entryPrice: 45000,
          currentPrice: 46000,
          pnl: 500,
          pnlPct: 2.22,
          allocation: 0.23,
        },
        {
          symbol: "ETH-USD",
          quantity: 10,
          entryPrice: 2400,
          currentPrice: 2450,
          pnl: 500,
          pnlPct: 2.08,
          allocation: 0.245,
        },
        {
          symbol: "CASH",
          quantity: 1,
          entryPrice: 1,
          currentPrice: 1,
          pnl: 0,
          pnlPct: 0,
          allocation: 0.525,
        },
      ],
      leverage: 0.475,
      maxLeverage: 2.0,
    };

    res.json(portfolio);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * GET /api/mobile/portfolio/equity-curve
 * Get equity curve for charting
 */
router.get("/mobile/portfolio/equity-curve", async (req: Request, res: Response) => {
  try {
    const days = Math.min(parseInt(req.query.days as string) || 30, 365);

    // In production: fetch from DB or file
    const equityCurve = Array.from({ length: days }, (_, i) => ({
      date: new Date(Date.now() - (days - i) * 86400000).toISOString().split("T")[0],
      equity: 100000 + Math.random() * 5000 - 2500 + i * 100,
      drawdown: Math.random() * 5,
    }));

    res.json({
      days,
      data: equityCurve,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ============================================================================
// 6. ALERTS & NOTIFICATIONS
// ============================================================================

/**
 * POST /api/mobile/alerts
 * Set price alert
 */
router.post("/mobile/alerts", async (req: Request, res: Response) => {
  try {
    const { symbol, type, price } = req.body;

    if (!symbol || !type || !price) {
      return res.status(400).json({ error: "symbol, type, price required" });
    }

    const alert = {
      id: Math.random().toString(36).substring(7),
      symbol,
      type, // 'above' or 'below'
      price,
      createdAt: new Date().toISOString(),
      triggered: false,
    };

    res.json({
      success: true,
      alert,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

/**
 * GET /api/mobile/alerts
 * Get user's active alerts
 */
router.get("/mobile/alerts", async (req: Request, res: Response) => {
  try {
    const alerts = [
      {
        id: "1",
        symbol: "BTC-USD",
        type: "above",
        price: 47000,
        createdAt: new Date().toISOString(),
        triggered: false,
      },
    ];

    res.json({
      count: alerts.length,
      alerts,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ============================================================================
// 7. DASHBOARD - Quick overview
// ============================================================================

/**
 * GET /api/mobile/dashboard
 * Get quick dashboard overview
 */
router.get("/mobile/dashboard", async (req: Request, res: Response) => {
  try {
    // Get latest scanner results
    const scannerPath = path.join(process.cwd(), "quant-sim/runs/latest_scan.json");
    let topSignals = [];
    if (fs.existsSync(scannerPath)) {
      topSignals = JSON.parse(fs.readFileSync(scannerPath, "utf-8")).slice(0, 5);
    }

    // Get portfolio summary
    const portfolio = {
      equity: 102500,
      pnl: 2500,
      pnlPct: 2.5,
      positions: 2,
      leverage: 0.475,
    };

    // Get latest trades
    const recentRun = await db.query.runs.findFirst();
    let recentTrades = [];
    if (recentRun) {
      const tradesPath = path.join(recentRun.artifactsDir, "trades.csv");
      if (fs.existsSync(tradesPath)) {
        const csv = fs.readFileSync(tradesPath, "utf-8");
        recentTrades = csv
          .split("\n")
          .slice(1, 6)
          .map((line: string) => {
            const [ts, symbol, qty, price] = line.split(",");
            return { ts, symbol, qty: parseFloat(qty), price: parseFloat(price) };
          })
          .filter((t: any) => t.symbol);
      }
    }

    res.json({
      timestamp: new Date().toISOString(),
      portfolio,
      topSignals: topSignals.slice(0, 5),
      recentTrades: recentTrades.slice(0, 5),
      alerts: {
        active: 3,
        triggered: 0,
      },
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

export default router;
