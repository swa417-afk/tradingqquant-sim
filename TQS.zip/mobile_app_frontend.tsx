/**
 * Mobile Trading App - Complete Frontend
 * Works with Mobiroller or any mobile framework
 * Build with: React + TypeScript + Tailwind CSS
 */

// ============================================================================
// 1. MAIN APP COMPONENT
// ============================================================================

import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  TrendingUp,
  Wallet,
  Bell,
  Search,
  Plus,
  X,
  Eye,
  EyeOff,
} from "lucide-react";

const API_BASE = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

export function MobileApp() {
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "scanner" | "watchlist" | "portfolio" | "settings"
  >("dashboard");
  const [showBalance, setShowBalance] = useState(true);

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">TradingQ</h1>
          <div className="flex gap-2">
            <button className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700">
              <Bell size={20} />
            </button>
            <button className="p-2 bg-slate-800 rounded-lg hover:bg-slate-700">
              <Search size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {activeTab === "dashboard" && <DashboardTab />}
        {activeTab === "scanner" && <ScannerTab />}
        {activeTab === "watchlist" && <WatchlistTab />}
        {activeTab === "portfolio" && <PortfolioTab />}
        {activeTab === "settings" && <SettingsTab />}
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 flex justify-around p-2">
        {[
          { id: "dashboard" as const, icon: BarChart3, label: "Dashboard" },
          { id: "scanner" as const, icon: TrendingUp, label: "Scanner" },
          { id: "watchlist" as const, icon: Plus, label: "Watchlist" },
          { id: "portfolio" as const, icon: Wallet, label: "Portfolio" },
          { id: "settings" as const, icon: Bell, label: "Settings" },
        ].map(({ id, icon: Icon, label }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition ${
              activeTab === id ? "bg-blue-600 text-white" : "text-slate-400"
            }`}
          >
            <Icon size={20} />
            <span className="text-xs">{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

// ============================================================================
// 2. DASHBOARD TAB
// ============================================================================

function DashboardTab() {
  const { data: dashboard, isLoading } = useQuery({
    queryKey: ["dashboard"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/dashboard`);
      return res.json();
    },
  });

  const [showBalance, setShowBalance] = useState(true);

  if (isLoading) return <LoadingCard />;

  return (
    <div className="space-y-4">
      {/* Equity Card */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl p-6 text-white space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm text-blue-100">Total Equity</span>
          <button
            onClick={() => setShowBalance(!showBalance)}
            className="p-1"
          >
            {showBalance ? <Eye size={20} /> : <EyeOff size={20} />}
          </button>
        </div>

        <div className="space-y-2">
          {showBalance ? (
            <>
              <div className="text-4xl font-bold">${dashboard?.portfolio?.equity?.toLocaleString()}</div>
              <div className="text-blue-100 text-sm">
                Balance • Updated {new Date().toLocaleTimeString()}
              </div>
            </>
          ) : (
            <div className="text-4xl font-bold">••••••</div>
          )}
        </div>

        {/* P&L */}
        <div className="bg-white bg-opacity-20 rounded-lg p-3 space-y-2">
          <div className="flex justify-between items-center">
            <span>P&L (Today)</span>
            <span
              className={`text-lg font-bold ${
                dashboard?.portfolio?.pnl >= 0 ? "text-green-300" : "text-red-300"
              }`}
            >
              {dashboard?.portfolio?.pnl >= 0 ? "+" : ""}
              ${dashboard?.portfolio?.pnl?.toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span>{dashboard?.portfolio?.pnlPct?.toFixed(2)}%</span>
            <span>{dashboard?.portfolio?.positions} Positions</span>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard label="Leverage" value={`${dashboard?.portfolio?.leverage?.toFixed(2)}x`} />
        <StatCard label="Max Leverage" value="2.0x" />
      </div>

      {/* Top Signals */}
      <div className="bg-slate-800 rounded-xl p-4">
        <h3 className="font-semibold mb-3">Top Signals 🔥</h3>
        <div className="space-y-2">
          {dashboard?.topSignals?.slice(0, 3)?.map((signal: any) => (
            <SignalItem key={signal.symbol} signal={signal} />
          ))}
        </div>
      </div>

      {/* Recent Trades */}
      <div className="bg-slate-800 rounded-xl p-4">
        <h3 className="font-semibold mb-3">Recent Trades</h3>
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {dashboard?.recentTrades?.map((trade: any, i: number) => (
            <TradeItem key={i} trade={trade} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 3. SCANNER TAB - Momentum stocks
// ============================================================================

function ScannerTab() {
  const [limit, setLimit] = useState(20);

  const { data: scannerResults, isLoading } = useQuery({
    queryKey: ["scanner", limit],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/scanner?limit=${limit}`);
      return res.json();
    },
    refetchInterval: 10000, // Refresh every 10s
  });

  if (isLoading) return <LoadingCard />;

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <input
          type="text"
          placeholder="Search symbol..."
          className="flex-1 bg-slate-800 rounded-lg px-3 py-2 text-sm"
        />
        <button className="px-3 py-2 bg-blue-600 rounded-lg text-sm font-semibold">
          Filter
        </button>
      </div>

      <div className="text-xs text-slate-400">
        {scannerResults?.count} stocks with momentum • Updated{" "}
        {new Date(scannerResults?.timestamp).toLocaleTimeString()}
      </div>

      <div className="space-y-2">
        {scannerResults?.results?.map((result: any) => (
          <ScannerResult key={result.symbol} result={result} />
        ))}
      </div>
    </div>
  );
}

function ScannerResult({ result }: { result: any }) {
  return (
    <div className="bg-slate-800 rounded-lg p-3 space-y-2 hover:bg-slate-700 cursor-pointer transition">
      <div className="flex justify-between items-start">
        <div>
          <div className="font-semibold">{result.symbol}</div>
          <div className="text-xs text-slate-400">${result.price?.toFixed(2)}</div>
        </div>
        <div className="text-right">
          <div
            className={`font-bold ${result.pctChange5m >= 0 ? "text-green-400" : "text-red-400"}`}
          >
            {result.pctChange5m >= 0 ? "+" : ""}
            {result.pctChange5m?.toFixed(2)}%
          </div>
          <div className="text-xs text-slate-400">5m</div>
        </div>
      </div>

      {/* Tags */}
      <div className="flex gap-2 flex-wrap">
        {result.tags?.map((tag: string) => (
          <span
            key={tag}
            className="text-xs bg-blue-900 text-blue-200 px-2 py-1 rounded"
          >
            {tag}
          </span>
        ))}
      </div>

      {/* Score Bar */}
      <div className="bg-slate-700 rounded h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full"
          style={{ width: `${Math.min((result.score / 50) * 100, 100)}%` }}
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 text-xs text-slate-400">
        <div>
          RelVol: <span className="text-white">{result.relVol5m?.toFixed(1)}x</span>
        </div>
        <div>
          VWAP: <span className="text-white">{result.vwapDist?.toFixed(1)}%</span>
        </div>
        <div>
          Score: <span className="text-white">{result.score?.toFixed(0)}</span>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 4. WATCHLIST TAB
// ============================================================================

function WatchlistTab() {
  const { data: watchlist } = useQuery({
    queryKey: ["watchlist"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/watchlist`);
      return res.json();
    },
  });

  const [newSymbol, setNewSymbol] = useState("");

  const handleAdd = async () => {
    if (!newSymbol) return;

    try {
      await fetch(`${API_BASE}/mobile/watchlist`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol: newSymbol }),
      });
      setNewSymbol("");
    } catch (err) {
      console.error("Failed to add to watchlist", err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Add New */}
      <div className="flex gap-2">
        <input
          type="text"
          value={newSymbol}
          onChange={(e) => setNewSymbol(e.target.value.toUpperCase())}
          placeholder="BTC-USD, ETH-USD..."
          className="flex-1 bg-slate-800 rounded-lg px-3 py-2 text-sm"
        />
        <button
          onClick={handleAdd}
          className="px-4 py-2 bg-blue-600 rounded-lg font-semibold"
        >
          Add
        </button>
      </div>

      {/* Watchlist Items */}
      <div className="space-y-2">
        {watchlist?.items?.map((item: any) => (
          <WatchlistItem key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}

function WatchlistItem({ item }: { item: any }) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div
      className="bg-slate-800 rounded-lg p-4 space-y-3"
      onClick={() => setShowDetails(!showDetails)}
    >
      <div className="flex justify-between items-center cursor-pointer">
        <span className="font-semibold text-lg">{item.symbol}</span>
        <X
          size={20}
          className="text-red-400 cursor-pointer"
          onClick={(e) => {
            e.stopPropagation();
            // Delete logic
          }}
        />
      </div>

      {showDetails && (
        <div className="bg-slate-700 rounded p-3 space-y-2 text-sm">
          <div className="flex justify-between">
            <span>Added</span>
            <span>{new Date(item.addedAt).toLocaleDateString()}</span>
          </div>
          <div className="flex justify-between">
            <span>Alerts</span>
            <span>{item.alerts?.length || 0}</span>
          </div>
          <button className="w-full mt-2 py-2 bg-blue-600 rounded font-semibold text-sm">
            Set Alert
          </button>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 5. PORTFOLIO TAB
// ============================================================================

function PortfolioTab() {
  const { data: portfolio, isLoading } = useQuery({
    queryKey: ["portfolio"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/mobile/portfolio`);
      return res.json();
    },
    refetchInterval: 5000,
  });

  if (isLoading) return <LoadingCard />;

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-xl p-4 space-y-3">
        <div className="text-sm text-purple-100">Total Equity</div>
        <div className="text-3xl font-bold">${portfolio?.totalEquity?.toLocaleString()}</div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white bg-opacity-20 rounded p-2">
            <div className="text-xs text-purple-100">P&L (Today)</div>
            <div
              className={`font-bold ${portfolio?.totalPnl >= 0 ? "text-green-300" : "text-red-300"}`}
            >
              {portfolio?.totalPnl >= 0 ? "+" : ""}${portfolio?.totalPnl?.toLocaleString()}
            </div>
          </div>
          <div className="bg-white bg-opacity-20 rounded p-2">
            <div className="text-xs text-purple-100">P&L %</div>
            <div
              className={`font-bold ${portfolio?.pnlPct >= 0 ? "text-green-300" : "text-red-300"}`}
            >
              {portfolio?.pnlPct >= 0 ? "+" : ""}
              {portfolio?.pnlPct?.toFixed(2)}%
            </div>
          </div>
        </div>
      </div>

      {/* Leverage */}
      <div className="bg-slate-800 rounded-xl p-4">
        <div className="flex justify-between items-center mb-2">
          <span className="font-semibold">Leverage</span>
          <span className="text-sm">
            {portfolio?.leverage?.toFixed(2)}x / {portfolio?.maxLeverage}x
          </span>
        </div>
        <div className="bg-slate-700 rounded h-3 overflow-hidden">
          <div
            className="bg-yellow-500 h-full"
            style={{ width: `${(portfolio?.leverage / portfolio?.maxLeverage) * 100}%` }}
          />
        </div>
      </div>

      {/* Positions */}
      <div className="space-y-2">
        <h3 className="font-semibold">Positions ({portfolio?.positions?.length})</h3>
        {portfolio?.positions?.map((position: any) => (
          <PositionCard key={position.symbol} position={position} />
        ))}
      </div>
    </div>
  );
}

function PositionCard({ position }: { position: any }) {
  return (
    <div className="bg-slate-800 rounded-lg p-3 space-y-2">
      <div className="flex justify-between items-start">
        <div>
          <div className="font-semibold">{position.symbol}</div>
          <div className="text-xs text-slate-400">
            {position.quantity.toFixed(4)} @ ${position.entryPrice?.toFixed(2)}
          </div>
        </div>
        <div className="text-right">
          <div
            className={`font-bold ${position.pnl >= 0 ? "text-green-400" : "text-red-400"}`}
          >
            {position.pnl >= 0 ? "+" : ""}${position.pnl?.toFixed(2)}
          </div>
          <div className="text-xs text-slate-400">{position.pnlPct?.toFixed(2)}%</div>
        </div>
      </div>

      <div className="text-xs text-slate-400 flex justify-between">
        <span>Current: ${position.currentPrice?.toFixed(2)}</span>
        <span>Allocation: {(position.allocation * 100).toFixed(1)}%</span>
      </div>
    </div>
  );
}

// ============================================================================
// 6. SETTINGS TAB
// ============================================================================

function SettingsTab() {
  return (
    <div className="space-y-4">
      <div className="bg-slate-800 rounded-xl p-4 space-y-3">
        <SettingItem label="Push Notifications" enabled={true} />
        <SettingItem label="Price Alerts" enabled={true} />
        <SettingItem label="Trade Notifications" enabled={true} />
      </div>

      <div className="bg-slate-800 rounded-xl p-4 space-y-3">
        <h3 className="font-semibold mb-3">Account</h3>
        <button className="w-full py-2 bg-slate-700 rounded text-sm hover:bg-slate-600">
          Logout
        </button>
      </div>

      <div className="text-xs text-slate-500 text-center">
        TradingQ Mobile v1.0.0
      </div>
    </div>
  );
}

function SettingItem({
  label,
  enabled,
}: {
  label: string;
  enabled: boolean;
}) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-sm">{label}</span>
      <button
        className={`relative w-12 h-6 rounded-full transition ${
          enabled ? "bg-green-600" : "bg-slate-600"
        }`}
      >
        <div
          className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition ${
            enabled ? "translate-x-6" : ""
          }`}
        />
      </button>
    </div>
  );
}

// ============================================================================
// 7. REUSABLE COMPONENTS
// ============================================================================

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-slate-800 rounded-lg p-3 space-y-1">
      <div className="text-xs text-slate-400">{label}</div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  );
}

function SignalItem({ signal }: { signal: any }) {
  return (
    <div className="flex justify-between items-center py-2 border-b border-slate-700 last:border-0">
      <div>
        <div className="font-semibold text-sm">{signal.symbol}</div>
        <div className="text-xs text-slate-400">Score: {signal.score?.toFixed(0)}</div>
      </div>
      <div
        className={`font-bold text-sm ${signal.pctChange5m >= 0 ? "text-green-400" : "text-red-400"}`}
      >
        {signal.pctChange5m >= 0 ? "+" : ""}
        {signal.pctChange5m?.toFixed(2)}%
      </div>
    </div>
  );
}

function TradeItem({ trade }: { trade: any }) {
  return (
    <div className="flex justify-between items-center py-2 border-b border-slate-700 last:border-0 text-sm">
      <div>
        <div className="font-semibold">{trade.symbol}</div>
        <div className="text-xs text-slate-400">{trade.ts}</div>
      </div>
      <div className="text-right">
        <div>{Math.abs(trade.qty).toFixed(2)} @ ${trade.price?.toFixed(2)}</div>
        <div className="text-xs text-slate-400">
          {trade.qty > 0 ? "BUY" : "SELL"}
        </div>
      </div>
    </div>
  );
}

function LoadingCard() {
  return (
    <div className="bg-slate-800 rounded-lg p-6 space-y-3 animate-pulse">
      <div className="h-4 bg-slate-700 rounded w-1/3" />
      <div className="h-8 bg-slate-700 rounded w-1/2" />
      <div className="h-4 bg-slate-700 rounded w-2/3" />
    </div>
  );
}

export default MobileApp;
