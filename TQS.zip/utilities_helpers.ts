/**
 * Mobile Trading App - Utilities & Helpers
 * File: src/lib/utils.ts
 */

// ============================================================================
// NUMBER FORMATTING
// ============================================================================

export function formatCurrency(value: number, decimals: number = 2): string {
  if (isNaN(value)) return "$0.00";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

export function formatPercent(value: number, decimals: number = 2): string {
  if (isNaN(value)) return "0.00%";
  const sign = value >= 0 ? "+" : "";
  return `${sign}${value.toFixed(decimals)}%`;
}

export function formatNumber(value: number, decimals: number = 2): string {
  if (isNaN(value)) return "0";
  return value.toFixed(decimals);
}

export function formatCompact(value: number): string {
  // 1234567 → "1.2M"
  if (value >= 1e9) return (value / 1e9).toFixed(1) + "B";
  if (value >= 1e6) return (value / 1e6).toFixed(1) + "M";
  if (value >= 1e3) return (value / 1e3).toFixed(1) + "K";
  return value.toFixed(0);
}

export function formatLargeNumber(value: number): string {
  return new Intl.NumberFormat("en-US").format(value);
}

// ============================================================================
// DATE/TIME FORMATTING
// ============================================================================

export function formatTime(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}

export function formatDate(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatDateTime(date: string | Date): string {
  return `${formatDate(date)} ${formatTime(date)}`;
}

export function timeAgo(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const seconds = Math.floor((Date.now() - d.getTime()) / 1000);

  let interval = seconds / 31536000;
  if (interval > 1) return Math.floor(interval) + "y";

  interval = seconds / 2592000;
  if (interval > 1) return Math.floor(interval) + "mo";

  interval = seconds / 86400;
  if (interval > 1) return Math.floor(interval) + "d";

  interval = seconds / 3600;
  if (interval > 1) return Math.floor(interval) + "h";

  interval = seconds / 60;
  if (interval > 1) return Math.floor(interval) + "m";

  return Math.floor(seconds) + "s";
}

// ============================================================================
// TAILWIND CLASSES
// ============================================================================

export function getPnLColor(value: number, dark: boolean = true): string {
  if (dark) {
    return value >= 0 ? "text-green-400" : "text-red-400";
  }
  return value >= 0 ? "text-green-600" : "text-red-600";
}

export function getPnLBgColor(value: number, dark: boolean = true): string {
  if (dark) {
    return value >= 0 ? "bg-green-900 bg-opacity-30" : "bg-red-900 bg-opacity-30";
  }
  return value >= 0 ? "bg-green-100" : "bg-red-100";
}

export function getStatusColor(status: string): string {
  switch (status?.toLowerCase()) {
    case "completed":
    case "success":
      return "bg-green-600";
    case "running":
    case "active":
      return "bg-blue-600";
    case "failed":
    case "error":
      return "bg-red-600";
    case "pending":
    case "waiting":
      return "bg-yellow-600";
    default:
      return "bg-gray-600";
  }
}

export function getSignalStatusColor(status: string): string {
  switch (status) {
    case "FILLED":
      return "text-green-400 bg-green-900 bg-opacity-30";
    case "BLOCKED":
      return "text-red-400 bg-red-900 bg-opacity-30";
    case "SKIPPED":
      return "text-yellow-400 bg-yellow-900 bg-opacity-30";
    default:
      return "text-gray-400 bg-gray-900 bg-opacity-30";
  }
}

export function getSignalStatusBgColor(status: string): string {
  switch (status) {
    case "FILLED":
      return "bg-green-900";
    case "BLOCKED":
      return "bg-red-900";
    case "SKIPPED":
      return "bg-yellow-900";
    default:
      return "bg-gray-900";
  }
}

export function getTagColor(tag: string): string {
  switch (tag?.toUpperCase()) {
    case "MOMO":
      return "bg-blue-900 text-blue-200";
    case "BREAKOUT":
      return "bg-green-900 text-green-200";
    case "ABOVE_VWAP":
      return "bg-purple-900 text-purple-200";
    case "HIGH_VOLUME":
      return "bg-orange-900 text-orange-200";
    default:
      return "bg-gray-700 text-gray-200";
  }
}

// ============================================================================
// DATA VALIDATION
// ============================================================================

export function isValidNumber(value: any): boolean {
  return typeof value === "number" && !isNaN(value) && isFinite(value);
}

export function isValidSymbol(symbol: string): boolean {
  // BTC-USD, ETH-USDT, AAPL, etc.
  return /^[A-Z0-9]{1,10}(-[A-Z]{3})?$/.test(symbol);
}

export function isValidPrice(price: number): boolean {
  return isValidNumber(price) && price > 0;
}

export function isValidQuantity(qty: number): boolean {
  return isValidNumber(qty) && qty !== 0;
}

// ============================================================================
// CALCULATIONS
// ============================================================================

export function calculatePnL(entryPrice: number, currentPrice: number, quantity: number): number {
  return (currentPrice - entryPrice) * quantity;
}

export function calculatePnLPercent(entryPrice: number, currentPrice: number): number {
  if (entryPrice === 0) return 0;
  return ((currentPrice - entryPrice) / entryPrice) * 100;
}

export function calculateAllocation(positionValue: number, totalEquity: number): number {
  if (totalEquity === 0) return 0;
  return (positionValue / totalEquity) * 100;
}

export function calculateLeverage(totalPositions: number, equity: number): number {
  if (equity === 0) return 0;
  return (totalPositions / equity) * 100;
}

export function calculateDrawdown(peakEquity: number, currentEquity: number): number {
  if (peakEquity === 0) return 0;
  return ((currentEquity - peakEquity) / peakEquity) * 100;
}

export function calculateSharpeRatio(returns: number[], riskFreeRate: number = 0.02): number {
  if (returns.length === 0) return 0;

  const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance =
    returns.reduce((a, r) => a + Math.pow(r - meanReturn, 2), 0) / returns.length;
  const stdDev = Math.sqrt(variance);

  if (stdDev === 0) return 0;
  return (meanReturn - riskFreeRate) / stdDev;
}

export function calculateWinRate(trades: Array<{ pnl: number }>): number {
  if (trades.length === 0) return 0;
  const winners = trades.filter((t) => t.pnl > 0).length;
  return (winners / trades.length) * 100;
}

// ============================================================================
// ARRAY/OBJECT UTILITIES
// ============================================================================

export function groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
  return array.reduce(
    (result, item) => {
      const groupKey = String(item[key]);
      if (!result[groupKey]) result[groupKey] = [];
      result[groupKey].push(item);
      return result;
    },
    {} as Record<string, T[]>
  );
}

export function sortBy<T>(array: T[], key: keyof T, desc: boolean = false): T[] {
  const sorted = [...array].sort((a, b) => {
    const aVal = a[key];
    const bVal = b[key];

    if (aVal < bVal) return desc ? 1 : -1;
    if (aVal > bVal) return desc ? -1 : 1;
    return 0;
  });

  return sorted;
}

export function filterBy<T>(array: T[], predicate: (item: T) => boolean): T[] {
  return array.filter(predicate);
}

export function uniqBy<T>(array: T[], key: keyof T): T[] {
  const seen = new Set();
  return array.filter((item) => {
    const val = item[key];
    if (seen.has(val)) return false;
    seen.add(val);
    return true;
  });
}

// ============================================================================
// STORAGE
// ============================================================================

export function getLocalStorage<T>(key: string, defaultValue?: T): T | null {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue ?? null;
  } catch {
    return defaultValue ?? null;
  }
}

export function setLocalStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    console.warn(`Failed to save ${key} to localStorage`);
  }
}

export function removeLocalStorage(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch {
    console.warn(`Failed to remove ${key} from localStorage`);
  }
}

// ============================================================================
// ERROR HANDLING
// ============================================================================

export function getErrorMessage(error: any): string {
  if (typeof error === "string") return error;
  if (error?.message) return error.message;
  if (error?.error) return error.error;
  return "An unknown error occurred";
}

export function logError(context: string, error: any): void {
  console.error(`[${context}]`, error);
  // TODO: Send to error tracking service (Sentry, etc.)
}

// ============================================================================
// DEBOUNCE & THROTTLE
// ============================================================================

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;

  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };

    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;

  return function executedFunction(...args: Parameters<T>) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

// ============================================================================
// RETRY LOGIC
// ============================================================================

export async function retry<T>(
  fn: () => Promise<T>,
  options: {
    maxAttempts?: number;
    delay?: number;
    backoff?: number;
  } = {}
): Promise<T> {
  const { maxAttempts = 3, delay = 1000, backoff = 1.5 } = options;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxAttempts) throw error;

      const waitTime = delay * Math.pow(backoff, attempt - 1);
      await new Promise((resolve) => setTimeout(resolve, waitTime));
    }
  }

  throw new Error("Retry failed");
}

// ============================================================================
// MISC
// ============================================================================

export function generateId(prefix: string = ""): string {
  return `${prefix}${Math.random().toString(36).substring(2, 11)}`;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function range(start: number, end: number, step: number = 1): number[] {
  const result: number[] = [];
  for (let i = start; i < end; i += step) {
    result.push(i);
  }
  return result;
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
